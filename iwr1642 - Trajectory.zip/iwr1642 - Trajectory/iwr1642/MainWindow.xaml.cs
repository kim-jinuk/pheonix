﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace RadarVisualizer
{
    public partial class MainWindow : Window
    {
        private SerialPort _dataPort;
        private SerialPort _cliPort;
        private readonly byte[] _magicWord = new byte[] { 2, 1, 4, 3, 6, 5, 8, 7 };
        private byte[] _buffer = new byte[65536];
        private int _bufferIndex = 0;
        private TlvParser _parser = new TlvParser();
        private const string ConfigFileName = "xwr16xx_profile_2025_06_12T12_43_17_656.cfg";

        private Dictionary<int, Track> _tracks = new();
        private int _nextTrackId = 0;

        private Polygon _radarOriginTriangle;

        public MainWindow()
        {
            InitializeComponent();
            SetupSerial("COM3", 921600);
            SetupCliPort("COM4", 115200);

            _radarOriginTriangle = new Polygon
            {
                Points = new PointCollection { new Point(490, 700), new Point(510, 700), new Point(500, 685) },
                Fill = Brushes.Red
            };
            RadarCanvas.Children.Add(_radarOriginTriangle);
        }

        private void SetupSerial(string portName, int baudRate)
        {
            _dataPort = new SerialPort(portName, baudRate);
            _dataPort.DataReceived += DataPort_DataReceived;
            _dataPort.Open();
        }

        private void SetupCliPort(string portName, int baudRate)
        {
            _cliPort = new SerialPort(portName, baudRate);
            _cliPort.Open();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cliPort != null && _cliPort.IsOpen)
            {
                string[] lines = File.ReadAllLines(ConfigFileName);
                foreach (string line in lines)
                {
                    _cliPort.WriteLine(line);
                    System.Threading.Thread.Sleep(10);
                }

                _cliPort.WriteLine("sensorStart");
                StatusText.Text = "Radar config sent and started.";
                RadarStateIndicator.Fill = Brushes.GreenYellow;
            }
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cliPort != null && _cliPort.IsOpen)
            {
                _cliPort.WriteLine("sensorStop");
                StatusText.Text = "";
                RadarOverlay.Children.Clear();
                TrackingOverlay.Children.Clear();

                RadarStateIndicator.Fill = Brushes.Red;

                _tracks.Clear();
                _nextTrackId = 0;
            }
        }

        private void DataPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int bytesToRead = _dataPort.BytesToRead;
            byte[] readBuffer = new byte[bytesToRead];
            _dataPort.Read(readBuffer, 0, bytesToRead);

            Array.Copy(readBuffer, 0, _buffer, _bufferIndex, bytesToRead);
            _bufferIndex += bytesToRead;

            ParseBuffer();
        }

        private void ParseBuffer()
        {
            int startIdx = FindMagicWord(_buffer, _bufferIndex);
            if (startIdx >= 0 && (_bufferIndex - startIdx) >= 52)
            {
                byte[] packet = _buffer.Skip(startIdx).ToArray();
                var detObj = _parser.Parse(packet);
                if (detObj != null)
                {
                    Dispatcher.Invoke(() => DrawDetections(detObj));
                }
                _bufferIndex = 0;
            }
        }

        private int FindMagicWord(byte[] buffer, int length)
        {
            for (int i = 0; i <= length - _magicWord.Length; i++)
            {
                if (_magicWord.SequenceEqual(buffer.Skip(i).Take(_magicWord.Length)))
                    return i;
            }
            return -1;
        }

        private void DrawDetections(DetectionObject detObj)
        {
            RadarOverlay.Children.Clear();

            var sb = new System.Text.StringBuilder();
            List<Point> canvasPoints = new();

            foreach (var (x, y) in detObj.Points)
            {
                var ellipse = new Ellipse
                {
                    Width = 6,
                    Height = 6,
                    Fill = Brushes.Blue
                };

                double canvasX = 50 + ((x + 5) / 10.0) * 900;
                double canvasY = 700 - ((y / 10.0) * 600);

                Canvas.SetLeft(ellipse, canvasX);
                Canvas.SetTop(ellipse, canvasY);
                RadarOverlay.Children.Add(ellipse);

                canvasPoints.Add(new Point(canvasX, canvasY));

                sb.AppendLine($"X: {x:F2}, Y: {y:F2}");
            }

            // DBSCAN + Bounding Box
            var clusters = DbscanCluster(canvasPoints, eps: 30, minPts: 7);

            foreach (var cluster in clusters)
            {
                double minX = cluster.Min(p => p.X);
                double maxX = cluster.Max(p => p.X);
                double minY = cluster.Min(p => p.Y);
                double maxY = cluster.Max(p => p.Y);

                var rect = new Rectangle
                {
                    Width = maxX - minX,
                    Height = maxY - minY,
                    Stroke = Brushes.Red,
                    StrokeThickness = 2
                };

                Canvas.SetLeft(rect, minX);
                Canvas.SetTop(rect, minY);
                RadarOverlay.Children.Add(rect);


                double centerX = (minX + maxX) / 2;
                double centerY = (minY + maxY) / 2;

                var centerDot = new Ellipse
                {
                    Width = 4,
                    Height = 4,
                    Fill = Brushes.DarkGreen
                };

                Canvas.SetLeft(centerDot, centerX);
                Canvas.SetTop(centerDot, centerY);
                TrackingOverlay.Children.Add(centerDot);
            }

            StatusText.Text = $"Detected Objects: {detObj.Points.Length}";
            DetectionLogText.Text = sb.ToString();

            // 중심점 추출
            var clusterCenters = clusters.Select(cluster =>
            {
                double cx = (cluster.Min(p => p.X) + cluster.Max(p => p.X)) / 2;
                double cy = (cluster.Min(p => p.Y) + cluster.Max(p => p.Y)) / 2;
                return new Point(cx, cy);
            }).ToList();

            // 거리 기반 ID 매칭 및 필터 업데이트
            HashSet<int> matched = new();
            foreach (var center in clusterCenters)
            {
                Track matchedTrack = null;
                double minDist = double.MaxValue;

                foreach (var track in _tracks.Values)
                {
                    double dist = (track.LastPosition - center).Length;
                    if (dist < 40 && dist < minDist && !matched.Contains(track.Id))
                    {
                        minDist = dist;
                        matchedTrack = track;
                    }
                }

                if (matchedTrack != null)
                {
                    matchedTrack.Update(center);
                    matched.Add(matchedTrack.Id);
                }
                else
                {
                    var newTrack = new Track(_nextTrackId++, center);
                    _tracks[newTrack.Id] = newTrack;
                    matched.Add(newTrack.Id);
                }
            }

            // 궤적 그리기
            foreach (var track in _tracks.Values)
            {
                var color = new SolidColorBrush(Color.FromRgb(
                    (byte)((track.Id * 97) % 255),
                    (byte)((track.Id * 43) % 255),
                    (byte)((track.Id * 157) % 255)));

                for (int i = 1; i < track.Trajectory.Count; i++)
                {
                    var p1 = ScaleToMiniMap(track.Trajectory[i - 1]);
                    var p2 = ScaleToMiniMap(track.Trajectory[i]);

                    var line = new Line
                    {
                        X1 = p1.X,
                        Y1 = p1.Y,
                        X2 = p2.X,
                        Y2 = p2.Y,
                        Stroke = color,
                        StrokeThickness = 1.5
                    };
                    TrajectoryMiniMap.Children.Add(line);
                }
            }


        }

        private Point ScaleToMiniMap(Point original)
        {
            // 원본 TrackingCanvas 좌표 범위
            double originalMinX = 50;
            double originalMinY = 100;

            // 미니맵 실제 그릴 영역의 시작점과 크기
            double miniMapStartX = 40;
            double miniMapStartY = 20;
            double miniMapWidth = 350;   // 390 - 40
            double miniMapHeight = 210;  // 230 - 20

            // 스케일 비율
            double scaleX = miniMapWidth / 900.0;  // 원본 X범위: 900
            double scaleY = miniMapHeight / 600.0; // 원본 Y범위: 600

            return new Point(
                miniMapStartX + (original.X - originalMinX) * scaleX,
                miniMapStartY + (original.Y - originalMinY) * scaleY
            );
        }


        private List<List<Point>> DbscanCluster(List<Point> points, double eps, int minPts)
        {
            var clusters = new List<List<Point>>();
            var visited = new HashSet<Point>();
            var noise = new HashSet<Point>();

            foreach (var p in points)
            {
                if (visited.Contains(p))
                    continue;

                visited.Add(p);
                var neighbors = GetNeighbors(points, p, eps);

                if (neighbors.Count < minPts)
                {
                    noise.Add(p);
                }
                else
                {
                    var cluster = new List<Point>();
                    clusters.Add(cluster);
                    ExpandCluster(p, neighbors, cluster, points, visited, eps, minPts);
                }
            }

            return clusters;
        }

        private void ExpandCluster(Point p, List<Point> neighbors, List<Point> cluster, List<Point> points, HashSet<Point> visited, double eps, int minPts)
        {
            cluster.Add(p);

            for (int i = 0; i < neighbors.Count; i++)
            {
                var np = neighbors[i];
                if (!visited.Contains(np))
                {
                    visited.Add(np);
                    var npNeighbors = GetNeighbors(points, np, eps);
                    if (npNeighbors.Count >= minPts)
                        neighbors.AddRange(npNeighbors.Where(n => !neighbors.Contains(n)));
                }

                if (!cluster.Contains(np))
                    cluster.Add(np);
            }
        }

        private List<Point> GetNeighbors(List<Point> points, Point center, double eps)
        {
            return points.Where(p => (p - center).Length <= eps).ToList();
        }
    }

    public class DetectionObject
    {
        public int NumObjects { get; set; }
        public (float X, float Y)[] Points { get; set; } = Array.Empty<(float, float)>();
    }


}


// 아래에 추가하세요:
public class KalmanFilter
{
    private double x, y, vx, vy;
    private readonly double dt = 1.0;

    public void Initialize(double initX, double initY)
    {
        x = initX;
        y = initY;
        vx = 0;
        vy = 0;
    }

    public void Predict()
    {
        x += vx * dt;
        y += vy * dt;
    }

    public void Update(double measX, double measY)
    {
        double alpha = 0.5;
        vx = (1 - alpha) * vx + alpha * (measX - x) / dt;
        vy = (1 - alpha) * vy + alpha * (measY - y) / dt;
        x = measX;
        y = measY;
    }

    public (double X, double Y) GetEstimate() => (x, y);
}

public class Track
{
    public int Id { get; }
    public KalmanFilter Filter { get; } = new();
    public List<Point> Trajectory { get; } = new();

    public Track(int id, Point initial)
    {
        Id = id;
        Filter.Initialize(initial.X, initial.Y);
        Trajectory.Add(initial);
    }

    public void Update(Point measurement)
    {
        Filter.Predict();
        Filter.Update(measurement.X, measurement.Y);
        var (x, y) = Filter.GetEstimate();
        Trajectory.Add(new Point(x, y));
    }

    public Point LastPosition => Trajectory.Last();
}
