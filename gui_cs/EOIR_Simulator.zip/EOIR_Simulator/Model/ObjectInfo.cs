﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EOIR_Simulator.Model
{
    public struct ObjectInfo
    {
        public ushort Class;
        public ushort X;
        public ushort Y;
        public ushort W;
        public ushort H;
        public float Confidence;

        public static ObjectInfo FromBytes(byte[] data, int offset)
        {
            return new ObjectInfo
            {
                Class = BitConverter.ToUInt16(data, offset),
                X = BitConverter.ToUInt16(data, offset + 2),
                Y = BitConverter.ToUInt16(data, offset + 4),
                W = BitConverter.ToUInt16(data, offset + 6),
                H = BitConverter.ToUInt16(data, offset + 8),
                Confidence = BitConverter.ToSingle(data, offset + 10)
            };
        }
    }
}
