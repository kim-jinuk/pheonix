#include "UdpSender.hpp"
#include "CfgLoader.hpp"
#include "TcpReceiver.hpp"
#include "controlMotor.hpp"  


#include <thread>
#include <chrono>
#include <csignal>
#include <atomic>
#include <iostream>
#include <mutex>

std::atomic<bool> keep_running(true);
std::atomic<bool> tcp_connected(false);


extern int angle_x;
extern int angle_y;
extern std::mutex angle_mutex;


void signal_handler(int) {
    keep_running = false;
}

// TCP 수신 스레드
void tcp_listener_thread(int port) {
    TcpReceiver receiver(port);

    while (keep_running) {
        std::cout << "[TCP] Waiting for client...\n";

        if (!receiver.AcceptConnection()) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        tcp_connected = true;
        std::cout << "[TCP] Client connected.\n";

        TcpCommand cmd;
        while (keep_running) {
            if (!receiver.TcpParsing(cmd)) {
                std::cout << "[TCP] Client disconnected.\n";
                tcp_connected = false;
                {
                    std::lock_guard<std::mutex> lock(angle_mutex);
                    angle_x = 90;
                    angle_y = 90;
                }
                UpdateMotor(0, 0); 
                break;
            }
            receiver.TcpAngle(cmd.dx, cmd.dy);
            UpdateMotor(cmd.dx, cmd.dy);
        }
    }
}


// UDP 송신 스레드
void udp_sender_thread(const std::string& ip, int port) {
    UdpSender sender(ip, port);
    sender.UdpInit();

    while (keep_running) {
        while (keep_running && !tcp_connected) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        while (keep_running && tcp_connected) {
            sender.CaptureAndStorePayload();
            
            uint8_t nx, ny;
            {
                std::lock_guard<std::mutex> lock(angle_mutex);
                nx = angle_x;
                ny = angle_y;
            }

            auto packets = sender.BuildUdpPackets({}, nx, ny);

            sender.UdpSend(packets);
            std::this_thread::sleep_for(std::chrono::milliseconds(33));
        }

        std::cout << "[UDP] Waiting for TCP reconnection...\n";
    }
}

int main() {
    InitMotor();

    std::cout << "sizeof(ObjectInfo): " << sizeof(ObjectInfo) << std::endl;


    
    std::signal(SIGINT, signal_handler);

    CfgLoader cfg;
    if (!cfg.load("config.cfg")) {
        std::cerr << "[ERR] Failed to load config.cfg\n";
        return 1;
    }

    std::string udp_ip = cfg.get("UDP_IP");
    int udp_port = std::stoi(cfg.get("UDP_PORT"));
    int tcp_port = std::stoi(cfg.get("TCP_PORT"));

    std::cout << "[MAIN] Config loaded: UDP(" << udp_ip << ":" << udp_port << "), TCP(" << tcp_port << ")\n";

    std::thread tcpThread(tcp_listener_thread, tcp_port);
    std::thread udpThread(udp_sender_thread, udp_ip, udp_port);

    tcpThread.join();
    udpThread.join();

    return 0;
}
