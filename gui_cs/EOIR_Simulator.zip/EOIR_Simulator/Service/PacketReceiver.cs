﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using EOIR_Simulator.Model;

namespace EOIR_Simulator.Service
{
    public class PacketReceiver : IDisposable
    {
        private readonly UdpClient _client;
        private readonly object _lock = new object();
        private CancellationTokenSource _cts;

        private readonly Dictionary<uint, Dictionary<ushort, byte[]>> _framePackets = new Dictionary<uint, Dictionary<ushort, byte[]>>();
        private readonly Dictionary<uint, int> _expectedCounts = new Dictionary<uint, int>();

        public event Action<FramePacket> FrameArrived;

        public PacketReceiver(int port)
        {
            _client = new UdpClient(port);
            System.Diagnostics.Debug.WriteLine($"[UDP] bind {port}"); //Debug
        }

        public void Start()
        {
            _cts = new CancellationTokenSource();
            Task.Run(() => ReceiveLoop(_cts.Token));
        }

        public void Stop()
        {
            _cts?.Cancel();
        }

        public void Dispose()
        {
            Stop();
            _client?.Dispose();
        }

        private const int HEADER_SIZE = 8;
        private const int OBJECTINFO_SIZE = 14;
        private const int META_SIZE = 2 + OBJECTINFO_SIZE * 5;  // nx, ny + 5 * ObjectInfo
        private const int PAYLOAD_OFFSET = HEADER_SIZE + META_SIZE;


        private async Task ReceiveLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    UdpReceiveResult res = await _client.ReceiveAsync();
                    byte[] pkt = res.Buffer;

                    if (pkt.Length < PAYLOAD_OFFSET) continue;

                    uint frameId = (uint)(pkt[0] << 24 | pkt[1] << 16 | pkt[2] << 8 | pkt[3]);
                    ushort packetId = (ushort)((pkt[4] << 8) | pkt[5]);
                    ushort totalPackets = (ushort)((pkt[6] << 8) | pkt[7]);

                    byte nx = pkt[8];
                    byte ny = pkt[9];

                    

                    List<ObjectInfo> objects = new List<ObjectInfo>();
                    for (int i = 0; i < 5; i++)
                    {
                        objects.Add(ObjectInfo.FromBytes(pkt, 10 + i * OBJECTINFO_SIZE));
                    }

                    byte[] payload = new byte[pkt.Length - PAYLOAD_OFFSET];
                    Buffer.BlockCopy(pkt, PAYLOAD_OFFSET, payload, 0, payload.Length);

                    lock (_lock)
                    {
                        if (!_framePackets.ContainsKey(frameId))
                        {
                            _framePackets[frameId] = new Dictionary<ushort, byte[]>();
                            _expectedCounts[frameId] = totalPackets;
                        }

                        _framePackets[frameId][packetId] = payload;

                        if (_framePackets[frameId].Count >= totalPackets)
                        {
                            using (var ms = new MemoryStream())
                            {
                                for (ushort i = 0; i < totalPackets; i++)
                                {
                                    if (_framePackets[frameId].TryGetValue(i, out var part))
                                        ms.Write(part, 0, part.Length);
                                }

                                byte[] jpeg = ms.ToArray();
                                FrameArrived?.Invoke(new FramePacket
                                {
                                    FrameId = frameId,
                                    JpegBytes = jpeg,
                                    Nx = nx,
                                    Ny = ny,
                                    Objects = objects
                                });
                            }

                            _framePackets.Remove(frameId);
                            _expectedCounts.Remove(frameId);
                        }
                    }
                }
                catch (ObjectDisposedException) { break; }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[ERR] 수신 오류: {ex.Message}");
                }
            }
        }

    }
}