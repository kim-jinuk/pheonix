﻿// MainWindow.xaml.cs
using System;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace RadarVisualizer
{
    public partial class MainWindow : Window
    {
        private SerialPort _dataPort;
        private SerialPort _cliPort;
        private readonly byte[] _magicWord = new byte[] { 2, 1, 4, 3, 6, 5, 8, 7 };
        private byte[] _buffer = new byte[65536];
        private int _bufferIndex = 0;
        private TlvParser _parser = new TlvParser();
        private const string ConfigFileName = "xwr16xx_profile.cfg";

        private Polygon _radarOriginTriangle;

        public MainWindow()
        {
            InitializeComponent();
            SetupSerial("COM4", 921600);
            SetupCliPort("COM3", 115200);

            // Add the red origin triangle once
            _radarOriginTriangle = new Polygon
            {
                Points = new PointCollection { new Point(490, 700), new Point(510, 700), new Point(500, 685) },
                Fill = Brushes.Red
            };
            RadarCanvas.Children.Add(_radarOriginTriangle);
        }

        private void SetupSerial(string portName, int baudRate)
        {
            _dataPort = new SerialPort(portName, baudRate);
            _dataPort.DataReceived += DataPort_DataReceived;
            _dataPort.Open();
        }

        private void SetupCliPort(string portName, int baudRate)
        {
            _cliPort = new SerialPort(portName, baudRate);
            _cliPort.Open();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cliPort != null && _cliPort.IsOpen)
            {
                string[] lines = File.ReadAllLines(ConfigFileName);
                foreach (string line in lines)
                {
                    _cliPort.WriteLine(line);
                    System.Threading.Thread.Sleep(10);
                }

                _cliPort.WriteLine("sensorStart");
                StatusText.Text = "Radar config sent and started.";

                RadarStateIndicator.Fill = Brushes.Red;
            }
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            if (_cliPort != null && _cliPort.IsOpen)
            {
                _cliPort.WriteLine("sensorStop");
                StatusText.Text = "";

                RadarCanvas.Children.Clear();
                RadarCanvas.Children.Add(_radarOriginTriangle);
                RadarStateIndicator.Fill = Brushes.Gray;
            }
        }

        private void DataPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int bytesToRead = _dataPort.BytesToRead;
            byte[] readBuffer = new byte[bytesToRead];
            _dataPort.Read(readBuffer, 0, bytesToRead);

            Array.Copy(readBuffer, 0, _buffer, _bufferIndex, bytesToRead);
            _bufferIndex += bytesToRead;

            ParseBuffer();
        }

        private void ParseBuffer()
        {
            int startIdx = FindMagicWord(_buffer, _bufferIndex);
            if (startIdx >= 0 && (_bufferIndex - startIdx) >= 52)
            {
                byte[] packet = _buffer.Skip(startIdx).ToArray();
                var detObj = _parser.Parse(packet);
                if (detObj != null)
                {
                    Dispatcher.Invoke(() => DrawDetections(detObj));
                }
                _bufferIndex = 0;
            }
        }

        private int FindMagicWord(byte[] buffer, int length)
        {
            for (int i = 0; i <= length - _magicWord.Length; i++)
            {
                if (_magicWord.SequenceEqual(buffer.Skip(i).Take(_magicWord.Length)))
                    return i;
            }
            return -1;
        }
        private void DrawDetections(DetectionObject detObj)
        {
            RadarCanvas.Children.Clear();
            RadarCanvas.Children.Add(_radarOriginTriangle);

            // x: ±2m, y: 0~2m 범위 필터링
            var filteredPoints = detObj.Points
                .Where(p => Math.Abs(p.X) <= 2.0f && p.Y >= 0.0f && p.Y <= 2.0f)
                .ToArray();

            foreach (var (x, y) in filteredPoints)
            {
                var ellipse = new Ellipse
                {
                    Width = 6,
                    Height = 6,
                    Fill = Brushes.Blue
                };

                // x: -2 ~ 2 → 캔버스 좌표: 50~950 (900px)
                double canvasX = 50 + ((x + 2) / 4.0) * 900;

                // y: 0 ~ 2 → 캔버스 Y 좌표: 700 (아래) ~ 100 (위)
                double canvasY = 700 - ((y / 2.0) * 600);

                Canvas.SetLeft(ellipse, canvasX);
                Canvas.SetTop(ellipse, canvasY);
                RadarCanvas.Children.Add(ellipse);
            }

            StatusText.Text = $"Detected Objects: {filteredPoints.Length}";
        }


    }

    public class DetectionObject
    {
        public int NumObjects { get; set; }
        public (float X, float Y)[] Points { get; set; } = Array.Empty<(float, float)>();
    }
}
